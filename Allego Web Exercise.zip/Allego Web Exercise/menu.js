$(".elipsis-menu").click(function(e){
    e.preventDefault();
    $(".dialog").show();
});